package Chess;

public class Game {
    Piece [] [] board;
    //constructor creates an empty board
    Game(){
        board=new Piece [8][8];

    }
}
