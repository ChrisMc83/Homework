package Chess;

public class Piece {//parent class all subsequent pieces inherit
    // from this class their position for example

    Position position;

    //method to see if the move will be valid ie fit in the 8x8 confines of a chess board

    boolean isValidMove (Position newPosition){
        if (newPosition.row>0 && newPosition.column>0  //column and row have a position above 0
        && newPosition.row<8 && newPosition.column<8) { //column and row have position less than 8
            return true;  //valid move
        } //if
        else {
            return false; //not a valid move
            }//else
    }//boolean method
}//class
