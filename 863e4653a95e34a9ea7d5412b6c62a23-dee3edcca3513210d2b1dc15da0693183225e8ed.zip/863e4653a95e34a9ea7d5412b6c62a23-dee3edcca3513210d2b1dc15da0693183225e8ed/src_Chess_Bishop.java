package Chess;

/*public class Bishop extends Piece {
/*For the Bishop, since it can only move diagonally,
we'd want to check that the number of vertical steps is equal to the number of horizontal steps.
 That is, the difference between the current and new column positions is t
 he same as the difference between the current and new row positions.

I've used Math.abs which takes the absolute value of that difference
 to always be a positive value, allowing this check to work for all 4 diagonal directions.
 */

   /*
    public boolean isValidMove(Position newPosition) {
        if (Math.abs(newPosition.column-this.column)==Math.abs(newPosition.row-this.row)){
            return true;
        }
        else {
            return false;
        }
    }
}*/
