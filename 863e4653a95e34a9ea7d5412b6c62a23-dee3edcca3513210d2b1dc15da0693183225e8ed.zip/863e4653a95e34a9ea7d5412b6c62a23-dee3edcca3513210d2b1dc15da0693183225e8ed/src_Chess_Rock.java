package Chess;

/*Using the keyword super here means that we want to run the actual method
in the super (or parent) class from inside the implementation in "this" class.

Which means in each of the child classes, before you get to check the custom movement,
 you can check if super.isValidMove(position) has returned false.
 If so, then no need to do any more checks and immediately return false;
 otherwise, continue checking.

The new implementation for the Rock class will look like this:


class Rock extends Piece{
    boolean isValidMove(Position newPosition){
        // First call the parent's method to check for the board bounds
        if(!super.isValidMove(position)){
            return false;
        }
        // If we passed the first test then check for the specific rock movement
        if(newPosition.column == this.column && newPosition.row == this.row){
            return true;
        }
        else{
            return false;
        }
    }
}
*/