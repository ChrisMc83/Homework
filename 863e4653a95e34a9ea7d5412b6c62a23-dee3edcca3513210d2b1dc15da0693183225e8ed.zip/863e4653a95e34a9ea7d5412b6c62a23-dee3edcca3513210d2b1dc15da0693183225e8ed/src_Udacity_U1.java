package Udacity;

public class U1 extends Rocket {

    @Override
    public boolean launch() {
        double random=Math.random();
        return random>this.chanceLaunchExplosion;
    }

    @Override
    public boolean land(){
        double random=Math.random();
        return random>this.chanceLandExplosion;
    }

     /*
    Rocket cost = $100 Million
    Rocket weight = 10 Tonnes
    Max weight (with cargo) = 18 Tonnes
    Chance of launch explosion = 5% * (cargo carried / cargo limit)
    Chance of landing crash = 1% * (cargo carried / cargo limit)
     */

    double cargoCarried,cargoLimit;
    double costRocket = 100000000;
    int weightRocket = 10;
    int maxWeight= 18;
    double ChanceLaunchExplosion = 0.05* ((double) weightRocket/(double) maxWeight);
    double ChanceLandExplosion = 0.01*((double) weightRocket/(double) maxWeight);

}
