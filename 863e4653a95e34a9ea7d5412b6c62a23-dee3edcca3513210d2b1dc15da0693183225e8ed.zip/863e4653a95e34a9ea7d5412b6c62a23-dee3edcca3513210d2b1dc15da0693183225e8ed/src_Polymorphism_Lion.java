package Polymorphism;

public class Lion extends Animal {
    //overide
    public void makeNoise(){
        System.out.println("The Lion ROARRRS!");
    }
}
