package Udacity;

public interface Spaceship {

        boolean launch ();
        boolean land();
        boolean canCarry(double Item);
        double carry(double Item);



    }



