package GuestList;

import java.util.Scanner;

import static GuestList.Main.scanner;

public class Menu {

    public static void DisplayMenu() {

        System.out.println();
        System.out.println("1 - Display All Guests");
        System.out.println("2 - Add Guest");
        System.out.println("3 - Remove Guest");
        System.out.println("4 - Exit");

    }
}

