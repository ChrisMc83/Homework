package PolymorphicProcessing;

public class Researcher extends Employee {
    @Override
    public void calculateWeeklyPay(int hoursWorked) {
        //wages include a 1.5% weekly bonus
        double wages=hoursWorked*this.basePay*1.5;
        System.out.printf ("%s : %s: %.2f" ,this.name,this.jobTitle,wages);

    }
}
