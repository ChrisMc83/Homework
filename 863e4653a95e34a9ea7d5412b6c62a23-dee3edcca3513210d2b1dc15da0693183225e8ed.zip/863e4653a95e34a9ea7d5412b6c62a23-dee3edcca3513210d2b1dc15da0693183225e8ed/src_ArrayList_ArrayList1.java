package ArrayList;

import java.util.ArrayList;

public class ArrayList1 {
    public static void main(String[] args) {

        //create and initialize an ArrayList
        ArrayList grades = new ArrayList();


        //add elements using add() method
        grades.add(100);
        grades.add(97);
        grades.add(85);

        //et the first item in a list
        grades.get(0);

        //print out at array 1

        System.out.println (grades.get(1));

        /*Also, notice that we don't need to specify
        the initial size of an ArrayList:

ArrayList myArrayList = new ArrayList();

Unlike what we used to do with arrays:

int[] myArray = new int[100];
This is because the ArrayList class takes
 care of resizing the internal array every time it runs out of
 space, which is all done behind the scenes
 so you don’t have to worry about implementing any of that.
         */


    }
}


