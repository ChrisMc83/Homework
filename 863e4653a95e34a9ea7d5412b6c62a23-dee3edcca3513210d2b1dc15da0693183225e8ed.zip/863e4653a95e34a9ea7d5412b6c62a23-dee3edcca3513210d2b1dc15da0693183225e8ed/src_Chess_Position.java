package Chess;

public class Position {  //stores current position of piece
    int row,column;

    //create constructor
    Position (int r,int c){
    this.row=r;
    this.column=c;
    }
}
