package BridgingCourseWork;
import java.io.*;
import java.util.Arrays;

public class Coursework1 {


    public static int[] readArrayFromFile(String filename) {
        /*
        Description: Reads an array from file using UUlib.
        Parameters:  filename of textfile.
        Returns: int array of numbers
        */
        int[] array = new int[1];

        try {

            FileReader fr = new FileReader(filename);
            BufferedReader br = new BufferedReader(fr);
            String c = br.readLine();
            Integer size = Integer.parseInt(c);
            array = new int[size];
            System.out.println(array.length);

            for (int i = 0; i < size; i++) {

                c = br.readLine();
                array[i] = Integer.parseInt(c);
                System.out.println(array[i]);
            }
            br.close();
            fr.close();
        } catch (IOException e) {
            System.out.println(e);
        }
        return array;
    }

    public static int countPositiveValues(int[] array) {
        /*
        Description: Counts the positive integer values in an array
        Parameters:  int array to be counted
        Returns: int number of positive values
        */
        int positiveCount = 0;
        // Task: Complete method code

        //for loop to iterate through each element of the array
        //if greater than zero positive count increments
        for (int index = 0; index < array.length; index++) {
            if (array[index] >= 0) {
                positiveCount++;
            }//for
        }//if
        return positiveCount;

    }

    public static int countNegativeValues(int[] array) {
        /*
        Description: Counts the negative integer values in an array
        Parameters:  int array to be counted
        Returns: int number of negative values
        */
        int negativeCount = 0;
        //for loop to iterate through each element of the array
        //if less than zero negative count increments

        for (int index = 0; index < array.length; index++) {
            if (array[index] < 0) {
                negativeCount++;
            }//for
        }//if
        return negativeCount;
    }

    public static int countZeroValues(int[] array) {
        /*
        Description: Counts the zero integer values in an array
        Parameters:  int array to be counted
        Returns: int number of zero values
        */

        int zeroCount = 0;

        //for loop to iterate through array
        // //if equal to zero  then zeroCOunt increments
        for (int index = 0; index < array.length; index++) {
            if (array[index] == 0) {
                zeroCount++;
            }//if
        }//for
        return zeroCount;
    }

    public static double meanArrayValue(int[] array) {
        /*
        Description: Computes mean value from an array
        Parameters:  int array of values from which mean is computed
        Returns: double calculated mean value
        */
        double sum = 0;
        double meanValue;
        // Task: Complete method code
        //for loop to add up all the numbers
        for (int index = 0; index < array.length; index++) {
            sum = sum + array[index];
        }
        //formula to get the mean
        meanValue = sum / array.length;
        return meanValue;


    }


    public static double medianArrayValue(int[] array) {
        /*
        Description: Computes median value from a sorted array
        Parameters:  int array of values from which median is computed
        Returns: double calculated median value
        Note: Array must be sorted!
        */


        //Sort the array
        Arrays.sort(array);

        double median;
        int noOfElements = array.length;
        // if the length of array is even take the average of the two middle numbers
        if (noOfElements % 2 == 0) {
            int sumOfMiddleElements = array[noOfElements / 2] +
                    array[noOfElements / 2 - 1];
            // calculate average of middle elements
            median = ((double) sumOfMiddleElements) / 2;
        } else {
            // if the length of array  is odd find middle number
            median = ((double) array[array.length]) / 2;
        }//else
        return median;
    }//medianArrayValue


    public static int modeArrayValue(int[] array) {

        //We must first sort the array
        bubbleSort(array);

        int mode = 0, currentMax = 0;

        for (int i = 0; i < array.length; i++) {
            int numberOfAppearances = 0;
            //use nested for to compare number at index i with the numbers at all other indexes in the array i.e j
            //i starts at 0 compares that with j which starts at zero
            //i is still zero, j now incremented to 1, compare the two, i still zero, j now now 2, compare the two, so on and so forth
            for (int j = 0; j < array.length; j++) {
                if (array[i] == array[j]) {
                    //if there are duplicates count will go up by 1
                    numberOfAppearances++;
                }
            }//inner

            //if the current number appears more often than the number which previously held the record for the most number of appearances then it becomes the mode number
            if (numberOfAppearances > currentMax) {
                currentMax = numberOfAppearances;
                mode = array[i];
            }

        }//outer for
        return mode;
    }// calculate mode

    public static int minArrayValue(int[] array) {
        /*
        Description: Computes minimum value from an int array
        Parameters:  int array of values from which to find minimum
        Returns: int minimum value
        */

        // Task: Complete method code

        int smallest = array[0];//set smallest to first int in the array
        //loop through array assigning smallest as it goes along
        for (int index = 1; index < array.length; index++) {
            if (array[index] < smallest) {
                smallest = array[index];
            }//if
        }//for

        return smallest;
    }


    public static int maxArrayValue(int[] array) {
        /*
        Description: Computes maximum value from an int array
        Parameters:  int array of values from which to find maximum
        Returns: int maximum value
        */

        // Task: Complete method code
        int largest = array[0];//assign largest to int 0 in the array
        for (int index = 1; index < array.length; index++) {
            if (array[index] > largest) {
                largest = array[index];
            }//if
        }//for
        return largest;
    }

    public static void swap(int[] array, int posA, int posB) {
        /*
        Description: Swaps two values in an int array
        Parameters:  int array of values and positions of elements to be swapped
        Returns: void
        */
        int tmp = array[posA];
        array[posA] = array[posB];
        array[posB] = tmp;
    }//method


    public static void bubbleSort(int[] array) {
        /*
        Description: Sorts a int array using bubblesort algoritm
        Parameters:  int array of values to be sorted
        Returns: void
        */

        int ncomps = 0, nswaps = 0; // declare and initialise counters
        for (int out = array.length - 1; out > 0; out--) {
            for (int in = 0; in < out; in++) {
                ncomps++; // increment number of comparisons
                if (array[in] > array[in + 1]) {
                    nswaps++;  // increment number of swaps
                    swap(array, in, in + 1);
                }
            }
        }
        System.out.println("Comps=" + ncomps + " Swaps=" + nswaps);
    }

    public static int binarySearch(int array[], int key) {
        /*
        Description: Performs binary search on an array for a specified value
        Parameters:  int array of values and int key which item to be searched
        Returns: int indicating first location of item, or -1 in case not found
        */

        // Task: Complete method code

        //set first and last location
        int first = 0, last = array.length - 1, middle=first+last/2, comparisons = 0;

        while (first <= last) {
            if (array[middle] == key) {
                System.out.println(key + "\tFirst location found at " + (middle + 1));
break;
            } else if (array[middle] < key){
                first = middle + 1;
        }
             else
                last = middle - 1;

            middle = (first + last) / 2;

            ++comparisons;
        }//while

        return comparisons;
    }






            public static void main(String[] args) {


                // Read array from file and print
                int[] numbers = readArrayFromFile("practice.txt");

                // Task: Complete main method below
                // Read array from supplied text file (practice.txt) using method provided

                // Sort array using Bubble sort (code provided)

                // Compute the following stats from array obtained from text file
                // Total number of positive values
                // Total number of negative values
                // Total number of zero values
                // Minimum value
                // Maximum value
                // Mean, median and mode values
                // Search for key = 3555318 using Binary search
                System.out.println("\nTotal positives in array " + countPositiveValues(numbers) + "\n");
                System.out.println("\nTotal negatives in array " + countNegativeValues(numbers) + "\n");
                System.out.println("\nTotal zeros in array " + countZeroValues(numbers) + "\n");
                System.out.println("\nMinimum value in array " + minArrayValue(numbers) + "\n");
                System.out.println("\nMinimum value in array " + maxArrayValue(numbers) + "\n");
                System.out.println("\nMean value in array " + meanArrayValue(numbers) + "\n");
                System.out.println("\nMedian value in array " + medianArrayValue(numbers)+"\n");
                System.out.println("\nMode value in array " + modeArrayValue(numbers)+"\n");
                bubbleSort(numbers);
                System.out.println();
                binarySearch(numbers,3555318);


            }


}





















