package BankManager;

public class SavingsAccount extends BankAccount {
}
