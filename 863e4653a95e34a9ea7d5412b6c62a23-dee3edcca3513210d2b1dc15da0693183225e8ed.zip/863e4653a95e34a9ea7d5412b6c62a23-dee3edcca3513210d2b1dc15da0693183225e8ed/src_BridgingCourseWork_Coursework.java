package BridgingCourseWork;

import java.io.*;


public class Coursework {


    // Read array from file and print


    // Task: Complete main method below
    // Read array from supplied text file (practice.txt) using method provided

    // Sort array using Bubble sort (code provided)

    // Compute the following stats from array obtained from text file
    // Total number of positive values
    // Total number of negative values
    // Total number of zero values
    // Minimum value
    // Maximum value
    // Mean, median and mode values
    // Search for key = 3555318 using Binary search


    public static void main(String[] args) {

        /*
        Description: Reads an array from file using UUlib.
        Parameters:  filename of textfile.
        Returns: int array of numbers
        */


            try {
                int[] array = new int[1];

                FileReader fr = new FileReader("/Users/chris/CourseWork/src/practice.txt");
                BufferedReader br = new BufferedReader(fr);
                String c = br.readLine();
                Integer size = Integer.parseInt(c);
                array = new int[size];
                System.out.println(array.length);

                for (int i = 0; i < size; i++) {

                    c = br.readLine();
                    array[i] = Integer.parseInt(c);
                    System.out.println(array[i]);
                }
                br.close();
                fr.close();
            } catch (IOException e) {
                System.out.println(e);
            }

        }
    }






    