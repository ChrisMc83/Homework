package Udacity;

import java.util.ArrayList;

public class LoadU1 {
    Rocket U1= new Rocket() {
        @Override
        public boolean canCarry(double Item) {
            return false;
        }

        @Override
        public double carry(double Item) {
            return 0;
        }
    };



}
