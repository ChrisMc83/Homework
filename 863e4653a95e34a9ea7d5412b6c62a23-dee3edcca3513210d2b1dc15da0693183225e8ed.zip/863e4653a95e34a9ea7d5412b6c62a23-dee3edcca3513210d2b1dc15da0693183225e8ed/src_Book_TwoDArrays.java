package Book;

public class TwoDArrays {

    /*
Figure 2.9 illustrates how to print the contents of a two-dimensional array.
The code works not only for rectangular two-dimensional arrays, but also for ragged two-dimensional arrays, in which the number of columns varies from row to row.
 This is easily handled by using m[i].length at line 11 to represent the number of columns in row i.
  We also handle the possibility that a row might be null (which is different than length 0), with the test at line 7.
   The main routine illustrates the declaration of two-dimen- sional arrays for the case where initial values are known.
   It is simply an extension of the one-dimensional case discussed in Section 2.4.1.
Array a is a straightforward rectangular matrix, array b has a null row, and array c is ragged.
     */
    public static void printMatrix(int[][] m) {

        for (int i = 0; i < m.length; i++) {
            if (m[i] == null) System.out.println("(null)");
            else {
                for (int j = 0; j < m[i].length; j++) System.out.print(m[i][j] + " ");
                System.out.println();
            }
        }
    }

    public static void main(String[] args) {
        int[][] a = {{1, 2}, {3, 4}, {5, 6}};
        int[][] b = {{1, 2}, null, {5, 6}};
        int[][] c = {{1, 2}, {3, 4, 5}, {6}};
        System.out.println("a: ");
        printMatrix(a);
        System.out.println("b: ");
        printMatrix(b);
        System.out.println("c: ");
        printMatrix(c);

    }
}
