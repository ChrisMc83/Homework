package BankManager;

public class COD extends BankAccount {
}
