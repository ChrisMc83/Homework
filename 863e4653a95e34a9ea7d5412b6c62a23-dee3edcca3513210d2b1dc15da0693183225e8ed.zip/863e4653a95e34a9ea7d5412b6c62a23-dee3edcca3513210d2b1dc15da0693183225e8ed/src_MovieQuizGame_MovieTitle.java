package MovieQuizGame;

public class MovieTitle {
    public static Object movieName;

}
