package BridgingCourseWork;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class WordCount {

    public static void main (String [] args) throws FileNotFoundException {

        File file=new File("example.rtf");//use the file we want

        Scanner scanner=new Scanner(file);//set up scanner to scan the file

        int words=0;//initialise word count to 0

        while(scanner.hasNextLine()) {//while the scanner is able to read a new line in the document
            String line = scanner.nextLine();

            words += line.split("").length;//the "" indicates spaces and therefore indicates words
        }
        System.out.println("The file contains "+words+ " words");




        }






    }

