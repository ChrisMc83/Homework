package Udacity;

public class Item {

    String name;

    int weight;


}
