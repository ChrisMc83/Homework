package BankManager;

public class CheckingAccount extends BankAccount {
    double limit;

}
