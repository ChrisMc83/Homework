package PolymorphicProcessing;

public class Employee {
    String name,jobTitle;
    double basePay=30.00;

    public void calculateWeeklyPay(int hoursWorked){
        double wages=hoursWorked*this.basePay;
        System.out.printf ("%s : %s: %.2f" ,this.name,this.jobTitle,wages);

    }


}
