package MovieQuizGame;

import java.io.FileNotFoundException;

import static MovieQuizGame.Game.setMovieTitle;
import static MovieQuizGame.Game.welcome;

public class Main {

    public static void main (String [] args) throws FileNotFoundException {

        welcome();
        setMovieTitle();

    }


    }
