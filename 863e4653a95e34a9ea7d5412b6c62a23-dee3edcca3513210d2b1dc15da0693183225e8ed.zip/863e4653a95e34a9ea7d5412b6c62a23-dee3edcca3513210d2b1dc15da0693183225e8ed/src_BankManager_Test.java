package BankManager;

public class Test {
    public static void main (String[] args){
        BankAccount john=new BankAccount(33222,1233);
        System.out.println(john);



    }
}
