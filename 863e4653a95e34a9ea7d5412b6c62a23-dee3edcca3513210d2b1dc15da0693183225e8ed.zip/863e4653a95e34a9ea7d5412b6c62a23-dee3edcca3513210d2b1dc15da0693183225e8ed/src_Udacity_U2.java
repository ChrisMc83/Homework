package Udacity;

public class U2 extends Rocket {


    @Override
    public boolean launch() {
        double random=Math.random();
        return random>this.chanceLaunchExplosion;
    }

    @Override
    public boolean land() {
        double random = Math.random();
        return random > this.chanceLandExplosion;
    }


    double costRocket = 120000000;
    int weightRocket = 18;
    int maxWeight = 29;
    double Chanceoflaunchexplosion = 4 * ((double) weightRocket/(double) maxWeight);
    double Chanceoflandingcrash = 8 * ((double) weightRocket/(double) maxWeight);


}
