package PolymorphicProcessing;

/*example of runtime polymorphism-uses inheritance and interfaces
called through the reference variable of the superclass.Determination
of method to be called is based on the OBJECT being referred to by the
reference variable
 */

public class PayrollManager_TEST {
    public static void main (String[] args) {
        //create staff
        Employee e1 = new Researcher();//new researcher object
        e1.name = "Adam Researcher";
        e1.jobTitle = "Researcher";

        Employee e2 = new Employee();
        e2.name = "Joe Soap";
        e2.jobTitle = "Cleaner";

        Employee e3 = new Lecturer();
        e3.name = "Aidan McG";
        e3.jobTitle = "Lecturer";

        Employee[] employees = {e1, e2, e3}; //array of all employees all subclasses or superclass

        processPay(employees, 40);//call the process pay method
    }

        public static void processPay(Employee [] employees, int hours){
        /*each employee is cycled through when we invoke the employee its the specific method relevant to their class
            that is called and overides the super class method
            means you can pass all the employess and their different methods to calculate the pay without having to do individual ones*/

        for (Employee e:employees){
            e.calculateWeeklyPay(hours);
            System.out.println();



            //you can keep adding employee types as long as they extend employee and add it into the array
        }




    }
}
