package Lab1;

/*
6. Complete the outline methods in the Volume class below which calculate the
volume of both a Sphere and a Cylinder using the following formulas.
Volume Sphere = PI d3
 6
 Volume Cylinder = PI d2 h
 4
Use the math function Math.pow(double n, double p) to calculate a
number n to power p. Likewise use the Math.PI constant to obtain the value of
PI.
Import java.lang.math;
public class Volume {
 // calculate volume of sphere with specified diameter
 public static double volumeSphere(double d) {
 // code goes here
 }
 // calculate volume of cylinder with specified diameter and height
 public static int volumeCylinder(double d, double h) {
 // code goes here
 }
}
Call the methods with the following values
Sphere Diameter 10 has a volume of 523.598
Cylinder Diameter 10 height 10 has a volume of 785.398
 */


    public class Volume {
        // calculate volume of sphere with specified diameter
        public static double volumeSphere(double d) {
            double ans=Math.PI*Math.pow(d,3)/6;
            return ans;



        }
        public static void main (String [] args){
           System.out.println ( volumeSphere(10));

        }
}
