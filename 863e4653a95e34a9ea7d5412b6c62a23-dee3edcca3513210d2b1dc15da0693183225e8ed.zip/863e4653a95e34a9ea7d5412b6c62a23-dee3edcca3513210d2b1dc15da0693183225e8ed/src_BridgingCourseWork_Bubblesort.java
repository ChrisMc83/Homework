package BridgingCourseWork;


import java.util.Arrays;

public class Bubblesort {
    public static void BubbleSort(int[] nums) {

//sort an array using bubblesort
        int n = nums.length;


        for (int i = 0; i < n - 1; i++)//for loop

            for (int j = 0; j < n - 1 - i; j++)//nested for loop


                if (nums[j] > nums[j + 1]) {//if the number at j is less than the one to the right jump below

                    //move the numbers around
                    int temp = nums[j];
                    nums[j] = nums[j + 1];
                    nums[j + 1] = temp;

                }
    }

    public static void main (String [] args){
        Bubblesort test=new Bubblesort();
        int[] nums={302,427,240,307,800,289,808,382};



                    System.out.println("Original Array");
                    System.out.println(Arrays.toString(nums));
                    System.out.println("Amount of numbers= ");
                    System.out.println("New Array");
                    test.BubbleSort(nums);
                    System.out.println(Arrays.toString(nums));

                }
    }








