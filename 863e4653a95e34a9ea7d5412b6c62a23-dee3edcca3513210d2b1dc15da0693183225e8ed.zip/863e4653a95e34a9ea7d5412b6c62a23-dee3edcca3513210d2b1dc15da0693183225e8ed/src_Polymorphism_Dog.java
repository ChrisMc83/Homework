package Polymorphism;

public class Dog extends Animal {

    //overide
    public void makeNoise(){
        System.out.println("The Dog Barks!");
    }
}
