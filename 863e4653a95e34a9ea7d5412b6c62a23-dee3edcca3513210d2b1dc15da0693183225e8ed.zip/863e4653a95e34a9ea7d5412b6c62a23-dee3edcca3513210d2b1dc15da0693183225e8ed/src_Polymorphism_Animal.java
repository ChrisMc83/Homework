package Polymorphism;

public class Animal {
    public void makeNoise(){
        System.out.println ("This animal makes a noise");
    }
}
