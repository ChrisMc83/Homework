package PolymorphicProcessing;

public class Lecturer extends Employee {
    @Override
    public void calculateWeeklyPay(int hoursWorked) {
        //includes a weekly 5.5% Bonus
        double wages=hoursWorked*this.basePay*5.5;
        System.out.printf ("%s : %s: %.2f" ,this.name,this.jobTitle,wages);
    }
}
